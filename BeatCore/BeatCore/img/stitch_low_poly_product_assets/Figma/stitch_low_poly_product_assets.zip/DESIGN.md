---
name: Underground Street Audio & Tactile Sound
colors:
  surface: '#fcf9f4'
  surface-dim: '#ddd9d5'
  surface-bright: '#fcf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ef'
  surface-container: '#f1ede9'
  surface-container-high: '#ebe8e3'
  surface-container-highest: '#e5e2de'
  on-surface: '#1c1c19'
  on-surface-variant: '#4a4732'
  inverse-surface: '#31302e'
  inverse-on-surface: '#f4f0ec'
  outline: '#7b785f'
  outline-variant: '#ccc7ab'
  surface-tint: '#676000'
  primary: '#676000'
  on-primary: '#ffffff'
  primary-container: '#f4e400'
  on-primary-container: '#6c6500'
  inverse-primary: '#d8ca00'
  secondary: '#ba090d'
  on-secondary: '#ffffff'
  secondary-container: '#df2d24'
  on-secondary-container: '#fffbff'
  tertiary: '#006398'
  on-tertiary: '#ffffff'
  tertiary-container: '#c8e3ff'
  on-tertiary-container: '#00689f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#f6e607'
  primary-fixed-dim: '#d8ca00'
  on-primary-fixed: '#1f1c00'
  on-primary-fixed-variant: '#4e4800'
  secondary-fixed: '#ffdad5'
  secondary-fixed-dim: '#ffb4aa'
  on-secondary-fixed: '#410001'
  on-secondary-fixed-variant: '#930005'
  tertiary-fixed: '#cde5ff'
  tertiary-fixed-dim: '#94ccff'
  on-tertiary-fixed: '#001d32'
  on-tertiary-fixed-variant: '#004b74'
  background: '#fcf9f4'
  on-background: '#1c1c19'
  surface-variant: '#e5e2de'
typography:
  display-xl:
    fontFamily: Anton
    fontSize: 72px
    fontWeight: '400'
    lineHeight: 76px
    letterSpacing: 0.02em
  display-xl-mobile:
    fontFamily: Anton
    fontSize: 44px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: 0.02em
  headline-lg:
    fontFamily: Anton
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 52px
    letterSpacing: 0.02em
  headline-lg-mobile:
    fontFamily: Anton
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: 0.02em
  headline-md:
    fontFamily: Anton
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 32px
    letterSpacing: 0.03em
  headline-sm:
    fontFamily: Anton
    fontSize: 22px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0.03em
  body-lg:
    fontFamily: Space Mono
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Space Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Space Mono
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Space Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.1em
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system channels the visceral energy of underground sound systems, DIY cassette/zine subcultures, concrete street corners, and high-contrast hardware interfaces from the 1990s. Built for an independent audio hub dealing in physical media, heavy low-end acoustic hardware, and haptic audio gear, the aesthetic discards digital polish in favor of raw, unvarnished graphic brutalism.

### Personality & Tone
- **Raw & Visceral:** Unpolished, physical, anti-corporate. Visual weight reflects acoustic weight: thick strokes, heavy ink, industrial warning cues.
- **Utilitarian & Precise:** Technical specs, frequency response curves, and impedance values are delivered with the directness of workshop repair manuals and terminal readouts.
- **Street-Level Tactility:** References wheatpaste posters (lambe-lambe), vinyl center-labels, flight cases, hazard markings, and tactile rocker switches.

### Visual Foundations
The interface relies on ultra-high contrast, flat geometric surfaces, unrounded edges (0px border-radius across all elements), heavy black structural framing (3px solid lines), hard-cast offset shadow blocks without blur, and diagonal warning stripes. The interface looks printed, stamped, and wired rather than rendered.

## Colors

The palette operates on high-visibility industrial contrasts. Surfaces emulate newsprint, unbleached pasteboards, and asphalt, punched through with piercing caution primaries and phosphor LED accents.

### Core Palette
- **Caution Yellow (`#F4E400`):** Primary action token, high-energy banners, active states, and focal anchors.
- **Signal Red (`#E8342A`):** Secondary driver for destructive actions, alerts, live broadcast states, and limiter overloads.
- **Electric Blue (`#1E8FD5`):** Tertiary accent for specialized technical indicators, connectivity links, and digital inputs.
- **Asphalt Black (`#0B0B09`):** Primary ink for high-contrast borders, solid shadows, dominant display typography, and high-impact dark containers.
- **Kraft Off-White (`#F7F4E9`):** Base canvas color, evoking raw pulp paper, wheatpaste backdrops, and unbleached sleeves.
- **Dust Kraft (`#EFE9D6`):** Secondary background tier for inset panels, table heads, and nested module bodies.

### Functional Accents
- **PSX Neon Green (`#00FF66`):** Signal LED active state, stereo level peaks, and hardware availability status.
- **Hazard Stripe Pattern:** Diagonal repetition alternating between `#0B0B09` and `#F4E400` at 45-degree angles (16px rhythm) to signal limits, headers, or urgent sales alerts.

### Color Rules
- Never use opacity or alpha-channel translucency on core solid surfaces; colors meet along razor-sharp borders.
- Dark backgrounds use `#0B0B09` paired with inverse ink (`#F7F4E9` or `#F4E400`).

## Typography

Typography establishes an uncompromising hierarchy: punchy, compressed street poster headlines paired with rigorous monospaced data grids.

### Font Pairing Logic
- **Display & Headlines (`Anton`):** Heavy, condensed letterforms inspired by wooden poster type and DIY zine titles. Used strictly in uppercase (`text-transform: uppercase`) for category banners, product names, price points, and impact statements.
- **Body, Metadata & Labels (`Space Mono`):** Fixed-width typographic engine ensuring every specification (dB, Hz, Ohms, RPM, barcode keys) reads like an engineering schematic or receipt slip.

### Composition Rules
- Display titles must maintain tight line heights (`1.0` to `1.1`) to achieve the dense visual packing of pasted flyers.
- Technical specs and pricing must be rendered monospaced to align vertically without fluid variance.
- When pairing an `Anton` title with a `Space Mono` subline, enforce an uppercase prefix indicator such as `// SPEC_` or `[SYS_INIT]`.

## Layout & Spacing

Layout adheres to a dense modular system defined by black 3px perimeter lines, reminiscent of printed equipment schematics and classified listings.

### Structural Framework
- **Desktop (1024px+):** 12-column rigid grid with thick dividing borders. Containers stretch systematically to snap to neighboring borders with zero margin bleed. Margin is `2rem` (`32px`) and column gutter is `1.5rem` (`24px`).
- **Tablet (768px - 1023px):** 8-column layout. Multi-column equipment grids collapse to 2-up blocks; internal toolbars scroll horizontally with explicit directional arrows.
- **Mobile (Up to 767px):** Single-column stacked stream. Margin shifts to `1rem` (`16px`), gutter to `1rem` (`16px`). Layout items maintain outer 3px borders with bottom edge separators.

### Rhythm & Alignment
Spacing follows standard structural increments:
- `space-xs` (4px) / `space-sm` (8px): Internal tag padding, badge offsets, and segmented control borders.
- `space-md` (16px): Standard form element padding, card interior margins, and micro-grid gaps.
- `space-lg` (24px): Inter-module separation within cards and horizontal shelf gutters.
- `space-xl` (40px): Section transitions and banner stack intervals.

## Elevation & Depth

This system outright rejects blur-based drop shadows, diffuse lighting, and skeuomorphic gradients. Elevation is communicated through hard mechanical offsets, hard borders, and angled collage layering.

### Mechanical Projection (Hard Drop Shadows)
Elements achieve focus by extruding solid black planes directly beneath them:
- **Resting Level 1 (Cards, Badges, Data Modules):** `box-shadow: 4px 4px 0px #0B0B09`.
- **Interactive Level 2 (Buttons, Hovered Cards, Modals):** `box-shadow: 6px 6px 0px #0B0B09`.
- **Active State (Pressed):** `box-shadow: 0px 0px 0px #0B0B09; transform: translate(4px, 4px)`. The component physically sinks into the canvas upon interaction.

### Sticker & Collage Rotation
Tactile badges, limited-run vinyl stamps, and sale flags break the strict rectilinear grid by simulating manually pasted stickers:
- Default rotations: `-2deg`, `-3deg`, or `+2deg`.
- On hover, stickers animate via snappy transitions (`transform: rotate(0deg) scale(1.05); transition: transform 120ms cubic-bezier(0, 0, 0.2, 1)`).

### Atmospheric Texture
A faint monochrome analog noise overlay (`grain.png` at 3-4% opacity with CSS `mix-blend-mode: multiply`) coats base surfaces, preventing surfaces from feeling sterile.

## Shapes

The geometric directive is absolute: **Zero radius (`border-radius: 0px`) everywhere.**

### Rationale & Rules
- All edges terminate in 90-degree right angles.
- Buttons, input controls, images, cards, dialog windows, and pill badges must remain razor-edged.
- Chamfered or cut-corner aesthetics (clipped at 45 degrees, 8px) are reserved strictly for technical data tags and system notifications (`clip-path: polygon(...)`).
- Internal dividers within cards inherit the outer border weight (`3px solid #0B0B09`), dividing spaces cleanly into mechanical sections.

## Components

### Buttons
- **Primary ('btn-punk'):** Background `#F4E400`, color `#0B0B09`, border `3px solid #0B0B09`, font `Anton` uppercase, tracking wide. Shadow: `4px 4px 0px #0B0B09`. Hover: shadow expands to `6px 6px 0px #0B0B09` and shifts `translate(-2px, -2px)`. Active: `box-shadow: 0 0 0`, `translate(4px, 4px)`.
- **Destructive / Alert:** Background `#E8342A`, color `#F7F4E9`, border `3px solid #0B0B09`, hard shadow offset.
- **Ghost / Brutal Outline:** Background transparent, color `#0B0B09`, border `3px solid #0B0B09`. Hover: inverts to background `#0B0B09`, text `#F7F4E9`.

### Chips & Stickers
- **Sticker Badges:** Heavy border (`2px solid #0B0B09`), font `Space Mono` bold uppercase (`label-sm`), background `#F7F4E9` or `#00FF66`. Rotated statically at `-2deg`. Hover straightens to `0deg`.
- **Status LED Chip:** Black capsule containing a 6px solid square light (`#00FF66` for active sound gear, `#E8342A` for sold out), followed by monospaced code notation.

### Input Fields & Controls
- **Text Inputs:** Background `#F7F4E9`, border `3px solid #0B0B09`, caret `#E8342A`. Placeholder in muted monospaced tone. Focus state: background shifts to `#FFFFFF` with a thick outer line or inset highlight in `#F4E400`.
- **Checkboxes & Radios:** Unrounded square boxes with `3px solid #0B0B09` borders. Checked state renders a solid inner black square block (leaving a 2px gap) or a thick heavy black 'X'.

### Cards & Shelf Displays
- **Product & Release Cards:** Structured like heavy cardboard cassette slips. Outer boundary `3px solid #0B0B09`, background `#F7F4E9`, shadow `4px 4px 0px #0B0B09`. Internal imagery separated from specs by a solid horizontal divider rule (`3px solid #0B0B09`). Hover action lifts card with a `6px 6px 0px #0B0B09` shadow.

### Lists & Technical Data Tables
- **Spec Grids:** Alternating background rows (`#F7F4E9` and `#EFE9D6`). Borders between rows `1px solid #0B0B09`. Text aligned strictly left for metric keys and right for numerical data, styled in `Space Mono`.

### Specialized Audio System Elements
- **VU Level Meter:** Vertical or horizontal stack of non-rounded blocks running from `#0B0B09` to `#F4E400` to an overloaded `#E8342A` peak.
- **Hazard Ribbon Divider:** Full-width strip running alternating 45° black/yellow hazard lines at 24px height to section off exclusive drops or checkout steps.